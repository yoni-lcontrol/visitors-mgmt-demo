using Amadeus8.Configurations;
using Amadeus8.Data;
using Amadeus8.DTOs;
using Amadeus8.Entities;
using Amadeus8.Models;
using Amadeus8.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;

namespace Amadeus8.Tests;

public class CardholderCreationServiceTests
{
    // ──────────────────────────────────────────────
    // CreateCardholderAsync – happy path
    // ──────────────────────────────────────────────

    [Fact]
    public async Task CreateCardholderAsync_MinimalPayload_PersistsAndReturnsDto()
    {
        var db = CreateDb();
        var fakeApi = new FakeAmadeusApiClient
        {
            CreatedCardholder = new AmadeusCardholder
            {
                Id = "ch-uid-001",
                FirstName = "John",
                LastName = "Doe",
                Status = "Active"
            }
        };
        var sut = CreateSut(fakeApi, db);

        var dto = new CardholderCreateDto
        {
            FirstName = "John",
            LastName = "Doe"
        };

        var result = await sut.CreateCardholderAsync(dto, CancellationToken.None);

        Assert.Equal("ch-uid-001", result.AmadeusUid);
        Assert.Equal("John", result.FirstName);
        Assert.Equal("Doe", result.LastName);
        Assert.Equal("Active", result.Status);

        var entity = await db.Cardholders.FirstOrDefaultAsync(c => c.AmadeusUid == "ch-uid-001");
        Assert.NotNull(entity);
        Assert.Equal("John", entity.FirstName);
        Assert.Equal("Doe", entity.LastName);
    }

    [Fact]
    public async Task CreateCardholderAsync_WithAllFields_PersistsCorrectly()
    {
        var db = CreateDb();
        var fakeApi = new FakeAmadeusApiClient
        {
            CreatedCardholder = new AmadeusCardholder
            {
                Id = "ch-uid-002",
                CardholderIdNumber = "ID-12345",
                FirstName = "Jane",
                LastName = "Smith",
                Status = "Active",
                SecurityGroupApiKey = "sg-key",
                AccessGroupApiKeys = "ag1,ag2"
            }
        };
        var sut = CreateSut(fakeApi, db);

        var from = DateTime.UtcNow.AddHours(1);
        var to = DateTime.UtcNow.AddDays(7);

        var dto = new CardholderCreateDto
        {
            CardholderIdNumber = "ID-12345",
            FirstName = "Jane",
            LastName = "Smith",
            Description = "Test cardholder",
            SecurityGroupApiKey = "sg-key",
            AccessGroupApiKeys = new List<string> { "ag1", "ag2" },
            FromDateValid = from,
            ToDateValid = to,
            IsFromDateActive = true,
            IsToDateActive = true
        };

        var result = await sut.CreateCardholderAsync(dto, CancellationToken.None);

        Assert.Equal("ch-uid-002", result.AmadeusUid);
        Assert.Equal("ID-12345", result.CardholderIdNumber);
        Assert.Equal("ag1,ag2", result.AccessGroupApiKeysRaw);

        var entity = await db.Cardholders.FirstAsync(c => c.AmadeusUid == "ch-uid-002");
        Assert.True(entity.IsFromDateActive);
        Assert.True(entity.IsToDateActive);
    }

    [Fact]
    public async Task CreateCardholderAsync_SendsCorrectPayloadToApi()
    {
        var db = CreateDb();
        var fakeApi = new FakeAmadeusApiClient
        {
            CreatedCardholder = new AmadeusCardholder { Id = "ch-uid-003" }
        };
        var sut = CreateSut(fakeApi, db);

        var dto = new CardholderCreateDto
        {
            FirstName = "Alice",
            LastName = "Brown",
            CardholderIdNumber = "ID-99",
            SecurityGroupApiKey = "sg-test",
            AccessGroupApiKeys = new List<string> { "ag-a", "ag-b" },
            Description = "desc"
        };

        await sut.CreateCardholderAsync(dto, CancellationToken.None);

        Assert.NotNull(fakeApi.LastCreatePayload);
        var payload = (Dictionary<string, object?>)fakeApi.LastCreatePayload!;
        Assert.Equal("Alice", payload["FirstName"]);
        Assert.Equal("Brown", payload["LastName"]);
        Assert.Equal("ID-99", payload["CardholderIdNumber"]);
        Assert.Equal("sg-test", payload["SecurityGroupApiKey"]);
        Assert.Equal("ag-a,ag-b", payload["AccessGroupApiKeys"]);
        Assert.Equal("desc", payload["Description"]);
    }

    // ──────────────────────────────────────────────
    // License plate
    // ──────────────────────────────────────────────

    [Fact]
    public async Task CreateCardholderAsync_WithLicensePlate_CallsUpsertAndPersists()
    {
        var db = CreateDb();
        var fakeApi = new FakeAmadeusApiClient
        {
            CreatedCardholder = new AmadeusCardholder { Id = "ch-uid-010", FirstName = "Tom", LastName = "Jones" }
        };
        var sut = CreateSut(fakeApi, db);

        var dto = new CardholderCreateDto
        {
            FirstName = "Tom",
            LastName = "Jones",
            LicensePlate = "ABC-123"
        };

        var result = await sut.CreateCardholderAsync(dto, CancellationToken.None);

        // License plate stored on DTO result
        Assert.Equal("ABC-123", result.LicensePlate);

        // UpsertLicensePlateAsync was called with the correct cardholder UID
        Assert.Equal("ch-uid-010", fakeApi.LastUpsertedLicensePlateUid);
        Assert.Equal("ABC-123", fakeApi.LastUpsertedLicensePlate);

        // Persisted to local entity
        var entity = await db.Cardholders.FirstAsync(c => c.AmadeusUid == "ch-uid-010");
        Assert.Equal("ABC-123", entity.LicensePlate);
    }

    [Fact]
    public async Task CreateCardholderAsync_WithoutLicensePlate_DoesNotCallUpsert()
    {
        var db = CreateDb();
        var fakeApi = new FakeAmadeusApiClient
        {
            CreatedCardholder = new AmadeusCardholder { Id = "ch-uid-011" }
        };
        var sut = CreateSut(fakeApi, db);

        var dto = new CardholderCreateDto { FirstName = "No", LastName = "Plate" };

        await sut.CreateCardholderAsync(dto, CancellationToken.None);

        Assert.Null(fakeApi.LastUpsertedLicensePlateUid);

        var entity = await db.Cardholders.FirstAsync(c => c.AmadeusUid == "ch-uid-011");
        Assert.Null(entity.LicensePlate);
    }

    [Fact]
    public async Task CreateCardholderAsync_EmptyLicensePlate_DoesNotCallUpsert()
    {
        var db = CreateDb();
        var fakeApi = new FakeAmadeusApiClient
        {
            CreatedCardholder = new AmadeusCardholder { Id = "ch-uid-012" }
        };
        var sut = CreateSut(fakeApi, db);

        var dto = new CardholderCreateDto { FirstName = "Empty", LastName = "Plate", LicensePlate = "  " };

        await sut.CreateCardholderAsync(dto, CancellationToken.None);

        Assert.Null(fakeApi.LastUpsertedLicensePlateUid);
    }

    // ──────────────────────────────────────────────
    // API error handling
    // ──────────────────────────────────────────────

    [Fact]
    public async Task CreateCardholderAsync_AmadeusApiThrows_PropagatesException()
    {
        var db = CreateDb();
        var fakeApi = new FakeAmadeusApiClient
        {
            ThrowOnCreate = new HttpRequestException("Cardholder create failed with status 500")
        };
        var sut = CreateSut(fakeApi, db);

        var dto = new CardholderCreateDto { FirstName = "Fail", LastName = "Test" };

        await Assert.ThrowsAsync<HttpRequestException>(
            () => sut.CreateCardholderAsync(dto, CancellationToken.None));

        // Nothing should be persisted
        Assert.Empty(await db.Cardholders.ToListAsync());
    }

    [Fact]
    public async Task CreateCardholderAsync_AmadeusApiThrows_NothingPersistedLocally()
    {
        var db = CreateDb();
        var fakeApi = new FakeAmadeusApiClient
        {
            ThrowOnCreate = new HttpRequestException("Conflict")
        };
        var sut = CreateSut(fakeApi, db);

        try
        {
            await sut.CreateCardholderAsync(new CardholderCreateDto { FirstName = "X", LastName = "Y" }, CancellationToken.None);
        }
        catch (HttpRequestException) { }

        Assert.Equal(0, await db.Cardholders.CountAsync());
    }

    // ──────────────────────────────────────────────
    // GetCardholdersAsync / GetCardholderByUidAsync
    // ──────────────────────────────────────────────

    [Fact]
    public async Task GetCardholdersAsync_ReturnsOnlyNonDeletedOrderedByName()
    {
        var db = CreateDb();
        db.Cardholders.AddRange(
            new CardholderEntity { AmadeusUid = "u1", FirstName = "Bob", LastName = "Alpha", IsDeleted = false, CreatedUtc = DateTime.UtcNow, UpdatedUtc = DateTime.UtcNow },
            new CardholderEntity { AmadeusUid = "u2", FirstName = "Alice", LastName = "Alpha", IsDeleted = false, CreatedUtc = DateTime.UtcNow, UpdatedUtc = DateTime.UtcNow },
            new CardholderEntity { AmadeusUid = "u3", FirstName = "Gone", LastName = "Deleted", IsDeleted = true, CreatedUtc = DateTime.UtcNow, UpdatedUtc = DateTime.UtcNow }
        );
        await db.SaveChangesAsync();

        var sut = CreateSut(new FakeAmadeusApiClient(), db);

        var result = await sut.GetCardholdersAsync(CancellationToken.None);

        Assert.Equal(2, result.Count);
        Assert.DoesNotContain(result, c => c.IsDeleted);
        Assert.Equal("Alice", result[0].FirstName);
        Assert.Equal("Bob", result[1].FirstName);
    }

    [Fact]
    public async Task GetCardholderByUidAsync_Exists_ReturnsDto()
    {
        var db = CreateDb();
        db.Cardholders.Add(new CardholderEntity
        {
            AmadeusUid = "find-me",
            FirstName = "Find",
            LastName = "Me",
            LicensePlate = "XY-999",
            IsDeleted = false,
            CreatedUtc = DateTime.UtcNow,
            UpdatedUtc = DateTime.UtcNow
        });
        await db.SaveChangesAsync();

        var sut = CreateSut(new FakeAmadeusApiClient(), db);

        var result = await sut.GetCardholderByUidAsync("find-me", CancellationToken.None);

        Assert.NotNull(result);
        Assert.Equal("find-me", result!.AmadeusUid);
        Assert.Equal("XY-999", result.LicensePlate);
    }

    [Fact]
    public async Task GetCardholderByUidAsync_NotFound_ReturnsNull()
    {
        var db = CreateDb();
        var sut = CreateSut(new FakeAmadeusApiClient(), db);

        var result = await sut.GetCardholderByUidAsync("does-not-exist", CancellationToken.None);

        Assert.Null(result);
    }

    // ──────────────────────────────────────────────
    // Helpers
    // ──────────────────────────────────────────────

    private static AmadeusDbContext CreateDb()
    {
        var options = new DbContextOptionsBuilder<AmadeusDbContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;
        return new AmadeusDbContext(options);
    }

    private static CardholderCommandService CreateSut(FakeAmadeusApiClient api, AmadeusDbContext db)
    {
        var amadeusOptions = Options.Create(new AmadeusOptions
        {
            BaseUrl = "http://test",
            Username = "test",
            Password = "test",
            VisitorCardholderTypeUid = "visitor-type-uid"
        });

        return new CardholderCommandService(
            api,
            db,
            amadeusOptions,
            NullLogger<CardholderCommandService>.Instance);
    }

    private sealed class FakeAmadeusApiClient : IAmadeusApiClient
    {
        public AmadeusCardholder? CreatedCardholder { get; set; }
        public HttpRequestException? ThrowOnCreate { get; set; }
        public object? LastCreatePayload { get; private set; }
        public string? LastUpsertedLicensePlateUid { get; private set; }
        public string? LastUpsertedLicensePlate { get; private set; }

        public Task<AmadeusCardholder> CreateCardholderAsync(object payload, CancellationToken cancellationToken)
        {
            LastCreatePayload = payload;
            if (ThrowOnCreate is not null) throw ThrowOnCreate;
            return Task.FromResult(CreatedCardholder ?? new AmadeusCardholder { Id = "default-uid" });
        }

        public Task<AmadeusCardholderPersonalDetails?> GetCardholderPersonalDetailsAsync(string cardholderUid, CancellationToken cancellationToken)
            => Task.FromResult<AmadeusCardholderPersonalDetails?>(null);

        public Task<AmadeusCardholderPersonalDetails> UpsertLicensePlateAsync(string cardholderUid, string licensePlate, CancellationToken cancellationToken)
        {
            LastUpsertedLicensePlateUid = cardholderUid;
            LastUpsertedLicensePlate = licensePlate;
            return Task.FromResult(new AmadeusCardholderPersonalDetails
            {
                CardholderUid = cardholderUid,
                CarLicensePlate = licensePlate
            });
        }

        public Task DeleteCardholderAsync(string uid, CancellationToken cancellationToken) => Task.CompletedTask;
        public Task UpdateCardholderAsync(string uid, object payload, CancellationToken cancellationToken) => Task.CompletedTask;

        public Task<List<AmadeusController>> GetControllersAsync(CancellationToken cancellationToken) => throw new NotImplementedException();
        public Task<(List<AmadeusController> Items, int? TotalCount)> GetControllersPagedAsync(int skip, int top, CancellationToken cancellationToken) => throw new NotImplementedException();
        public Task<List<AmadeusReader>> GetReadersAsync(CancellationToken cancellationToken) => throw new NotImplementedException();
        public Task<(List<AmadeusReader> Items, int? TotalCount)> GetReadersPagedAsync(int skip, int top, CancellationToken cancellationToken) => throw new NotImplementedException();
        public Task<List<AmadeusInput>> GetInputsAsync(CancellationToken cancellationToken) => throw new NotImplementedException();
        public Task<(List<AmadeusInput> Items, int? TotalCount)> GetInputsPagedAsync(int skip, int top, CancellationToken cancellationToken) => throw new NotImplementedException();
        public Task<List<AmadeusOutput>> GetOutputsAsync(CancellationToken cancellationToken) => throw new NotImplementedException();
        public Task<(List<AmadeusOutput> Items, int? TotalCount)> GetOutputsPagedAsync(int skip, int top, CancellationToken cancellationToken) => throw new NotImplementedException();
        public Task<List<AmadeusSecurityGroup>> GetSecurityGroupsAsync(CancellationToken cancellationToken) => throw new NotImplementedException();
        public Task<(List<AmadeusSecurityGroup> Items, int? TotalCount)> GetSecurityGroupsPagedAsync(int skip, int top, CancellationToken cancellationToken) => throw new NotImplementedException();
        public Task<List<AmadeusAccessGroup>> GetAccessGroupsAsync(CancellationToken cancellationToken) => throw new NotImplementedException();
        public Task<(List<AmadeusAccessGroup> Items, int? TotalCount)> GetAccessGroupsPagedAsync(int skip, int top, CancellationToken cancellationToken) => throw new NotImplementedException();
        public Task<(List<AmadeusCardholder> Items, int? TotalCount)> GetCardholdersPagedAsync(int skip, int top, CancellationToken cancellationToken) => throw new NotImplementedException();
        public Task<AmadeusCardholder?> GetCardholderByUidAsync(string uid, CancellationToken cancellationToken) => throw new NotImplementedException();
        public Task<AmadeusCardholder?> GetCardholderByIdNumberAsync(string cardholderIdNumber, CancellationToken cancellationToken) => Task.FromResult<AmadeusCardholder?>(null);
        public Task CreateCardAsync(string cardholderUid, string cardNumber, CancellationToken cancellationToken) => Task.CompletedTask;
    }
}
